package com.example.prep365;

public class MealPlan {
    private int index;
    private String bmiCategory;
    private String breakfast;
    private String lunch;
    private String dinner;
    private int breakfastCalories;
    private int lunchCalories;
    private int dinnerCalories;

    public MealPlan(int index, String bmiCategory, String breakfast, String lunch, String dinner, int breakfastCalories, int lunchCalories, int dinnerCalories) {
        this.index = index;
        this.bmiCategory = bmiCategory;
        this.breakfast = breakfast;
        this.lunch = lunch;
        this.dinner = dinner;
        this.breakfastCalories = breakfastCalories;
        this.lunchCalories = lunchCalories;
        this.dinnerCalories = dinnerCalories;
    }

    public int getIndexOfMeal() {
        return index;
    }
    public double getMaxBmi() {
        String[] bmiRange = bmiCategory.split("-");
        double minBMI = Double.parseDouble(bmiRange[0]);
        double maxBMI = Double.parseDouble(bmiRange[1]);

        return minBMI;
    }
    public void setIndex(int index) {
        this.index = index;
    }

    public String getBmiCategory() {
        return bmiCategory;
    }

    public void setBmiCategory(String bmiCategory) {
        this.bmiCategory = bmiCategory;
    }

    public String getBreakfast() {
        return breakfast;
    }

    public void setBreakfast(String breakfast) {
        this.breakfast = breakfast;
    }

    public String getLunch() {
        return lunch;
    }

    public void setLunch(String lunch) {
        this.lunch = lunch;
    }

    public String getDinner() {
        return dinner;
    }

    public void setDinner(String dinner) {
        this.dinner = dinner;
    }

    public int getBreakfastCalories() {
        return breakfastCalories;
    }

    public void setBreakfastCalories(int breakfastCalories) {
        this.breakfastCalories = breakfastCalories;
    }

    public int getLunchCalories() {
        return lunchCalories;
    }

    public void setLunchCalories(int lunchCalories) {
        this.lunchCalories = lunchCalories;
    }

    public int getDinnerCalories() {
        return dinnerCalories;
    }

    public void setDinnerCalories(int dinnerCalories) {
        this.dinnerCalories = dinnerCalories;
    }
}
