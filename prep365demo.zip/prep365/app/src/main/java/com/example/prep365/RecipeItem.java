package com.example.prep365;

import java.util.List;

public class RecipeItem {
    private int meal;
    private String recipe;
    private int calories;
    private List<String> ingredients;

    public RecipeItem(int meal, String recipe, int calories, List<String> ingredients) {
        this.meal = meal;
        this.recipe = recipe;
        this.calories = calories;
        this.ingredients = ingredients;
    }

    public int getMeal() {
        return meal;
    }

    public String getRecipe() {
        return recipe;
    }

    public int getCalories() {
        return calories;
    }

    public List<String> getIngredients() {
        return ingredients;
    }
}