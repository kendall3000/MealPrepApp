package com.example.prep365;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.example.prep365.MealPlan;



public class MealPlanActivity extends AppCompatActivity {
    private ImageButton imageButton2;
    private ImageButton imageButton3;
    private ImageButton imageButton4;
    private ImageButton imageButton5;
    private ArrayList<MealPlan> mealPlanList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_plan);
        imageButton2 = findViewById(R.id.imageButton2);
        imageButton3 = findViewById(R.id.imageButton3);
        imageButton4 = findViewById(R.id.imageButton4);
        imageButton5 = findViewById(R.id.imageButton5);
        imageButton2.setActivated(false);
        imageButton3.setActivated(false);
        imageButton4.setActivated(false);
        imageButton5.setActivated(false);
        imageButton2.setVisibility(View.GONE);
        imageButton3.setVisibility(View.GONE);
        imageButton4.setVisibility(View.GONE);
        imageButton5.setVisibility(View.GONE);
        Bundle extras = getIntent().getExtras();
        double test = getIntent().getDoubleExtra("bmi", 5);
        long bmi = Math.round(test);

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backIntent = new Intent(MealPlanActivity.this, UserActivity.class);
                startActivity(backIntent);
            }
        });

        if (extras != null) {
            // Check if the keys "bmi" and "allergyList" exist in the extras
            if (extras.containsKey("bmi") && extras.containsKey("allergies")) {

                Log.d("Meal Plan Info", "BMI Category: " + bmi);
                String allergyListConcatenated = extras.getString("allergies");
                Log.d("Meal Plan Info", "BMI Category: " + allergyListConcatenated);

                List<String> allergyList;
                if (!allergyListConcatenated.isEmpty()) {
                    allergyList = new ArrayList<>(Arrays.asList(allergyListConcatenated.split(",")));
                } else {
                    allergyList = new ArrayList<>();
                }

                List<MealPlan> mealPlans = loadMealPlans(getApplicationContext(), bmi);

                for (MealPlan mealPlan : mealPlans) {
                    Log.d("Meal Plan Info2", "Index: " + mealPlan.getIndexOfMeal());
                    Log.d("Meal Plan Info2", "BMI Category: " + mealPlan.getBmiCategory());
                    Log.d("Meal Plan Info2", "Breakfast: " + mealPlan.getBreakfast());
                    Log.d("Meal Plan Info2", "Lunch: " + mealPlan.getLunch());
                    Log.d("Meal Plan Info2", "Dinner: " + mealPlan.getDinner());
                    Log.d("Meal Plan Info2", "Breakfast Calories: " + mealPlan.getBreakfastCalories());
                    Log.d("Meal Plan Info2", "Lunch Calories: " + mealPlan.getLunchCalories());
                    Log.d("Meal Plan Info2", "Dinner Calories: " + mealPlan.getDinnerCalories());
                }

                if (!mealPlans.isEmpty()) { // Check if there are valid meal plans
                    int randomMealPlanIndex = getRandomMealPlanIndexForBMI(mealPlans, bmi, allergyList);
                    Log.d("error", "Meal Plan works");

                    if (randomMealPlanIndex != -1) {
                        MealPlan selectedMealPlan = mealPlans.get(randomMealPlanIndex);
                        Log.d("Selected", "Index: " + selectedMealPlan.getIndexOfMeal());
                        Log.d("Meal Plan Info2", "BMI Category: " + selectedMealPlan.getBmiCategory());
                        Log.d("Meal Plan Info2", "Breakfast: " + selectedMealPlan.getBreakfast());
                        Log.d("Meal Plan Info2", "Lunch: " + selectedMealPlan.getLunch());
                        Log.d("Meal Plan Info2", "Dinner: " + selectedMealPlan.getDinner());
                        Log.d("Meal Plan Info2", "Breakfast Calories: " + selectedMealPlan.getBreakfastCalories());
                        Log.d("Meal Plan Info2", "Lunch Calories: " + selectedMealPlan.getLunchCalories());
                        Log.d("Selected", "Dinner Calories: " + selectedMealPlan.getDinnerCalories());

                        if (selectedMealPlan.getMaxBmi() >= 14 && selectedMealPlan.getMaxBmi() <= 18) {
                            imageButton2.setActivated(true);
                            imageButton2.setVisibility(View.VISIBLE);
                            imageButton2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    startMealPlan(selectedMealPlan);
                                }
                            });

                        }
                        if (selectedMealPlan.getMaxBmi() >= 19 && selectedMealPlan.getMaxBmi() <= 22) {
                            imageButton3.setActivated(true);
                            imageButton3.setVisibility(View.VISIBLE);
                            imageButton3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    startMealPlan(selectedMealPlan);
                                }
                            });

                            Toast.makeText(this, "Your BMI is 19-22.", Toast.LENGTH_SHORT).show();

                        }
                        if (selectedMealPlan.getMaxBmi() >= 23 && selectedMealPlan.getMaxBmi() <= 26) {
                            imageButton4.setActivated(true);
                            imageButton4.setVisibility(View.VISIBLE);
                            imageButton4.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    startMealPlan(selectedMealPlan);
                                }
                            });
                            Toast.makeText(this, "Your BMI is 23-26.", Toast.LENGTH_SHORT).show();
                        }
                        if (selectedMealPlan.getMaxBmi() >= 27) {
                            imageButton5.setActivated(true);
                            imageButton5.setVisibility(View.VISIBLE);
                            imageButton5.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    startMealPlan(selectedMealPlan);
                                }
                            });
                        }
                    }


                } else {
                    Toast.makeText(this, "No Meals Found.", Toast.LENGTH_SHORT).show();
                }

            }
        }

    }

    public static List<MealPlan> loadMealPlans(Context context, double bmi) {
        ArrayList<MealPlan> mealPlans = new ArrayList<>();
        // Load CSV file using AssetsManager and Scanner
        AssetManager assetManager = context.getAssets();
        try (Scanner scanner = new Scanner(assetManager.open("mealplan.txt"))) {

            // Skip the header line
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");

                // Debug print for CSV data
                Log.d("info", "" + Arrays.toString(data));
                // Parse the CSV data
                int index = Integer.parseInt(data[0]);
                String bmiCategory = data[1];
                String breakfast = data[2];
                String lunch = data[3];
                String dinner = data[4];
                int breakfastCalories = Integer.parseInt(data[5]);
                int lunchCalories = Integer.parseInt(data[6]);
                int dinnerCalories = Integer.parseInt(data[7]);

                // Debug print for parsed values
                Log.d("error", "Parsed Values: " + index + ", " + bmiCategory + ", " + breakfast + ", " + lunch + ", " + dinner );

                // Check if the meal plan falls within the BMI range
                if (isWithinBMIRange(bmi, bmiCategory)) {
                    MealPlan mealPlan = new MealPlan(index, bmiCategory, breakfast, lunch, dinner, breakfastCalories, lunchCalories, dinnerCalories);
                    Log.d("Meal Plan Info", "Index: " + mealPlan.getIndexOfMeal());
                    Log.d("Meal Plan Info", "BMI Category: " + mealPlan.getBmiCategory());
                    Log.d("Meal Plan Info", "Breakfast: " + mealPlan.getBreakfast());
                    Log.d("Meal Plan Info", "Lunch: " + mealPlan.getLunch());
                    Log.d("Meal Plan Info", "Dinner: " + mealPlan.getDinner());
                    Log.d("Meal Plan Info", "Breakfast Calories: " + mealPlan.getBreakfastCalories());
                    Log.d("Meal Plan Info", "Lunch Calories: " + mealPlan.getLunchCalories());
                    Log.d("Meal Plan Info", "Dinner Calories: " + mealPlan.getDinnerCalories());
                    mealPlans.add(mealPlan);

                }
            }
            scanner.close();
        } catch (IOException e) {
            Log.d("error", "Cant open");
        }

        Log.d("Error", "Returning Meal Plans");
        for (MealPlan mealPlan : mealPlans) {
            Log.d("Meal Plan Info3", "Index: " + mealPlan.getIndexOfMeal());
            Log.d("Meal Plan Info2", "BMI Category: " + mealPlan.getBmiCategory());
            Log.d("Meal Plan Info2", "Breakfast: " + mealPlan.getBreakfast());
            Log.d("Meal Plan Info2", "Lunch: " + mealPlan.getLunch());
            Log.d("Meal Plan Info2", "Dinner: " + mealPlan.getDinner());
            Log.d("Meal Plan Info2", "Breakfast Calories: " + mealPlan.getBreakfastCalories());
            Log.d("Meal Plan Info2", "Lunch Calories: " + mealPlan.getLunchCalories());
            Log.d("Meal Plan Info2", "Dinner Calories: " + mealPlan.getDinnerCalories());
        }

        return mealPlans;
    }



    private static boolean isWithinBMIRange(double bmi, String bmiCategory) {

        String[] bmiRange = bmiCategory.split("-");
        double minBMI = Double.parseDouble(bmiRange[0]);
        double maxBMI = Double.parseDouble(bmiRange[1]);
        Log.d("error", "BMI Range: " + minBMI + " - " + maxBMI);
        Log.d("error", "" + bmi);
        return bmi >= minBMI && bmi <= maxBMI;

    }

    private int getRandomMealPlanIndexForBMI(List<MealPlan> mealPlans, double bmi, List<String> allergyList) {
        List<Integer> validIndices = new ArrayList<>();
        for (int i = 0; i < mealPlans.size(); i++) {
            if (isWithinBMIRange(bmi, mealPlans.get(i).getBmiCategory())) {
                if (allergyList.equals("")) { validIndices.add(i);}
                else if (!containsAllergyIngredients(mealPlans.get(i), allergyList)) {
                    validIndices.add(i);
                }
            }
        }
        if (validIndices.isEmpty()) {
            return -1;
        } else {
            Random random = new Random();
            return validIndices.get(random.nextInt(validIndices.size()));
        }
    }

    private boolean containsAllergyIngredients(MealPlan mealPlan, List<String> allergyList) {
        ArrayList<String> ingredientsToCheck = new ArrayList<>();

        // Add the ingredients of all recipes in the meal plan to the list to check
        if (mealPlan.getBreakfast() != null) {
            ingredientsToCheck.addAll(getRecipeIngredients(mealPlan.getBreakfast(), mealPlan));
        }
        if (mealPlan.getLunch() != null) {
            ingredientsToCheck.addAll(getRecipeIngredients(mealPlan.getLunch(), mealPlan));
        }
        if (mealPlan.getDinner() != null) {
            ingredientsToCheck.addAll(getRecipeIngredients(mealPlan.getDinner(), mealPlan));
        }
        // Check if any of the ingredients in the list are in the allergy list
        for (String ingredient : ingredientsToCheck) {
            if (allergyList.contains(ingredient)) {
                return true;
            }
        }
        return false;
    }

    private ArrayList<String> getRecipeIngredients(String recipe, MealPlan mealPlan) {
        ArrayList<String> ingredients = new ArrayList<>();

        try (Scanner scanner = new Scanner(getAssets().open("recipelist.txt"))) {
            if (scanner.hasNextLine()) {
                scanner.nextLine(); // Skip the header line
            }

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");

                // Parse the data from the line
                int index = Integer.parseInt(data[0]);
                int mealIndex = Integer.parseInt(data[1]);
                String recipeName = data[2];
                int calories = Integer.parseInt(data[3]);
                String[] ingredientArray = data[4].split(",");

                if (index == mealPlan.getIndexOfMeal()) {
                    ingredients.addAll(Arrays.asList(ingredientArray));
                }
            }

            scanner.close();
        } catch (IOException e) {

        }

        return ingredients;
    }
    public void startMealPlan(MealPlan selectedMealPlan) {
        Intent intent = new Intent(MealPlanActivity.this, MoreMealPlanActivity.class);
        intent.putExtra("imageButtonClicked", 1);
        intent.putExtra("indexOfMeal", selectedMealPlan.getIndexOfMeal());
        intent.putExtra("breakfast", selectedMealPlan.getBreakfast());
        intent.putExtra("bmiCategory", selectedMealPlan.getBmiCategory());
        intent.putExtra("lunch", selectedMealPlan.getLunch());
        intent.putExtra("dinner", selectedMealPlan.getDinner());
        intent.putExtra("dinnerCalories", selectedMealPlan.getDinnerCalories());
        intent.putExtra("lunchCalories", selectedMealPlan.getLunchCalories());
        intent.putExtra("breakfastCalories", selectedMealPlan.getBreakfastCalories());
        startActivity(intent);
    }
}
