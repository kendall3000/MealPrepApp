package com.example.prep365;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MoreMealPlanActivity extends AppCompatActivity {

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_meal_plan);

        Intent intent = getIntent();
        int imageButtonClicked = intent.getIntExtra("imageButtonClicked", 0);
        int indexOfMeal = intent.getIntExtra("indexOfMeal", 0);
        String breakfast = intent.getStringExtra("breakfast");
        String lunch = intent.getStringExtra("lunch");
        String dinner = intent.getStringExtra("dinner");
        int breakfastCalories = intent.getIntExtra("breakfastCalories", 0);
        int lunchCalories = intent.getIntExtra("lunchCalories", 0);
        int dinnerCalories = intent.getIntExtra("dinnerCalories", 0);


        TextView mealPlanTitleTextView = findViewById(R.id.mealPlanTitleTextView);
        TextView mealPlanDescriptionTextView = findViewById(R.id.mealPlanDescriptionTextView);
        TextView mealPlanDescriptionTextView1 = findViewById(R.id.mealPlanDescriptionTextView1);
        TextView mealPlanDescriptionTextView2 = findViewById(R.id.mealPlanDescriptionTextView2);

        mealPlanTitleTextView.setText("Meal Plan Example");

        mealPlanDescriptionTextView.setText(
                String.format("\t\tBreakfast\n %s\n -Calories Approximately %d-%d calories.",
                        breakfast, breakfastCalories, breakfastCalories));

        mealPlanDescriptionTextView1.setText(
                String.format("\t\tLunch\n %s\n -Calories Approximately %d-%d calories.",
                        lunch, lunchCalories, lunchCalories));

        mealPlanDescriptionTextView2.setText(
                String.format("\t\tDinner\n %s\n -Calories Approximately %d-%d calories.",
                        dinner, dinnerCalories, dinnerCalories));


        Button recipeButton = findViewById(R.id.recipeButton);
        recipeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent recipeIntent = new Intent(MoreMealPlanActivity.this, RecipeActivity.class);
                recipeIntent.putExtra("recipeType", imageButtonClicked);
                recipeIntent.putExtra("indexOfMeal", indexOfMeal);
                startActivity(recipeIntent);
            }
        });
    }
}

