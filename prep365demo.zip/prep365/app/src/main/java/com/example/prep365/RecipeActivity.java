package com.example.prep365;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class RecipeActivity extends AppCompatActivity {


    @SuppressLint({"DefaultLocale", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        TextView topText1 = findViewById(R.id.topText1);
        TextView bottomText1 = findViewById(R.id.bottomText1);
        TextView topText2 = findViewById(R.id.topText2);
        TextView bottomText2 = findViewById(R.id.bottomText2);
        TextView topText3 = findViewById(R.id.topText3);
        TextView bottomText3 = findViewById(R.id.bottomText3);

        int recipeIndex = getIntent().getIntExtra("indexOfMeal", 0);
        Log.d("Recipe Index", "Index: " + recipeIndex);

        List<RecipeItem> recipeItems = null;
        try {
            recipeItems = loadRecipeItems(recipeIndex);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if (recipeIndex >= 0 && recipeItems.size() == 3) {

            RecipeItem recipeItem1 = recipeItems.get(0);
            RecipeItem recipeItem2 = recipeItems.get(1);
            RecipeItem recipeItem3 = recipeItems.get(2);

            topText1.setText(String.format("Meal: %s\nRecipe: %s\nCalories: %d", recipeItem1.getMeal(), recipeItem1.getRecipe(), recipeItem1.getCalories()));
            bottomText1.setText("Ingredients:\n" + TextUtils.join(", ", recipeItem1.getIngredients()));

            topText2.setText(String.format("Meal: %s\nRecipe: %s\nCalories: %d", recipeItem2.getMeal(), recipeItem2.getRecipe(), recipeItem2.getCalories()));
            bottomText2.setText("Ingredients:\n" + TextUtils.join(", ", recipeItem2.getIngredients()));

            topText3.setText(String.format("Meal: %s\nRecipe: %s\nCalories: %d", recipeItem3.getMeal(), recipeItem3.getRecipe(), recipeItem3.getCalories()));
            bottomText3.setText("Ingredients:\n" + TextUtils.join(", ", recipeItem3.getIngredients()));

        }

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private List<RecipeItem> loadRecipeItems(int mealPlanIndex) throws IOException {
        List<RecipeItem> recipeItems = new ArrayList<>();

        try (Scanner scanner = new Scanner(getAssets().open("recipelist.txt"))) {
            if (scanner.hasNextLine()) {
                scanner.nextLine(); // Skip the header line
            }

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",", -1);

                // Make sure that the data array has at least 5 elements
                if (data.length >= 5) {
                    int recipeIndex = Integer.parseInt(data[0]);
                    int mealIndex = Integer.parseInt(data[1]);
                    String recipeName = data[2];
                    int calories = Integer.parseInt(data[3]);
                    List<String> ingredientsList = new ArrayList<>(Arrays.asList(data).subList(4, data.length));

                    Log.d("Recipe Info", "RecipeIndex: " + recipeIndex);
                    Log.d("Recipe Info", "MealIndex: " + mealIndex);
                    Log.d("Recipe Info", "Calories: " + calories);
                    Log.d("Recipe Info", "Ingredients: " + ingredientsList);


                    if (recipeIndex == mealPlanIndex) {
                        RecipeItem recipeItem = new RecipeItem(mealIndex, recipeName, calories, ingredientsList);
                        Log.d("Recipe Info2", "RecipeIndex: " + recipeItem.getRecipe());
                        Log.d("Recipe Info2", "MealIndex: " + mealIndex);
                        Log.d("Recipe Info2", "Calories: " + recipeItem.getCalories());
                        Log.d("Recipe Info2", "Ingredients: " + recipeItem.getIngredients());

                        recipeItems.add(recipeItem);
                    }


                }
            }

            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return recipeItems;
    }

}