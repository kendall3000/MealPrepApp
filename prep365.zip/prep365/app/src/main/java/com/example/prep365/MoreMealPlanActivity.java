package com.example.prep365;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MoreMealPlanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_meal_plan);

        Intent intent = getIntent();
        int imageButtonClicked = intent.getIntExtra("imageButtonClicked", 0);

        // Here you can customize the meal plan based on the image button clicked
        TextView mealPlanTitleTextView = findViewById(R.id.mealPlanTitleTextView);
        TextView mealPlanDescriptionTextView = findViewById(R.id.mealPlanDescriptionTextView);
        TextView mealPlanDescriptionTextView1 = findViewById(R.id.mealPlanDescriptionTextView1);
        TextView mealPlanDescriptionTextView2 = findViewById(R.id.mealPlanDescriptionTextView2);
        TextView mealPlanDescriptionTextView3 = findViewById(R.id.mealPlanDescriptionTextView3);
        TextView mealPlanDescriptionTextView4 = findViewById(R.id.mealPlanDescriptionTextView4);
        TextView mealPlanDescriptionTextView5 = findViewById(R.id.mealPlanDescriptionTextView5);
        TextView mealPlanDescriptionTextView6 = findViewById(R.id.mealPlanDescriptionTextView6);
        TextView mealPlanDescriptionTextView7 = findViewById(R.id.mealPlanDescriptionTextView7);
        TextView mealPlanDescriptionTextView8 = findViewById(R.id.mealPlanDescriptionTextView8);
        TextView mealPlanDescriptionTextView9 = findViewById(R.id.mealPlanDescriptionTextView9);
        TextView mealPlanDescriptionTextView10 = findViewById(R.id.mealPlanDescriptionTextView10);
        TextView mealPlanDescriptionTextView11 = findViewById(R.id.mealPlanDescriptionTextView11);



        if (imageButtonClicked == 2) {
            mealPlanTitleTextView.setText("Meal Plan Example");
            mealPlanDescriptionTextView.setText("\t\tBreakfast\n Avocado Toast with Eggs.\n -Calories Approximately 250-350 calories.");
            mealPlanDescriptionTextView1.setText("\t\tLunch\n -Turkey Wrap with ham and veggies.\n -Calories Approximately 300-400 calories.");
            mealPlanDescriptionTextView2.setText("\t\tDinner\n -Baked Salmon with Toasted Vegetables.\n -Calories Approximately 400-500 calories.");


        } else if (imageButtonClicked == 3) {
            mealPlanTitleTextView.setText("Meal Plan Example");
            mealPlanDescriptionTextView3.setText("\t\tBreakfast\n -Cheesy Egg Toast\n -Calories Approximately 140-240 calories.");
            mealPlanDescriptionTextView4.setText("\t\tLunch\n -Shrimp and Avocado Tostadas.\n -Calories Approximately 300-400 calories.");
            mealPlanDescriptionTextView5.setText("\t\tDinner\n -Honey BBQ Chicken Wings.\n -Calories Approximately 350-450 calories.");
        } else if (imageButtonClicked == 4) {
            mealPlanTitleTextView.setText("Meal Plan Example");
            mealPlanDescriptionTextView6.setText("\t\tBreakfast\n -Banana Pancakes.\n -Calories Approximately 186-286 calories.");
            mealPlanDescriptionTextView7.setText("\t\tLunch\n -BBQ Bacon Onion-Wrapped Meatballs.\n -Calories Approximately 600-700 calories.");
            mealPlanDescriptionTextView8.setText("\t\tDinner\n -Ham and Cheese Chicken Rollups.\n -Calories Approximately 500-600 calories.");
        } else if (imageButtonClicked == 5) {
            mealPlanTitleTextView.setText("Meal Plan Example");
            mealPlanDescriptionTextView9.setText("\t\tBreakfast\n -Breakfast Quesadilla.\n -Calories Approximately 400-500 calories.");
            mealPlanDescriptionTextView10.setText("\t\tLunch\n -Avocado Chicken Salad.\n -Calories Approximately 200-300 calories.");
            mealPlanDescriptionTextView11.setText("\t\tDinner\n -Bacon and Egg Fried Rice.\n -Calories Approximately 344-444 calories.");
        }

        Button recipeButton = findViewById(R.id.recipeButton);
        recipeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent recipeIntent = new Intent(MoreMealPlanActivity.this, RecipeActivity.class);
                recipeIntent.putExtra("recipeType", imageButtonClicked);
                startActivity(recipeIntent);
            }
        });


    }
}


