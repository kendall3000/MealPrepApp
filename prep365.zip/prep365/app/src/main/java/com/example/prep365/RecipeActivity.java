package com.example.prep365;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class RecipeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        // Get any data passed from MoreMealPlanActivity
        int recipeType = getIntent().getIntExtra("recipeType", 0);

        TextView recipeTitleTextView = findViewById(R.id.recipeTitleTextView);
        TextView recipeDescriptionTextView = findViewById(R.id.recipeDescriptionTextView);
        TextView recipeDescriptionTextView1 = findViewById(R.id.recipeDescriptionTextView1);
        TextView recipeDescriptionTextView2 = findViewById(R.id.recipeDescriptionTextView2);
        TextView recipeDescriptionTextView3 = findViewById(R.id.recipeDescriptionTextView3);
        TextView recipeDescriptionTextView4 = findViewById(R.id.recipeDescriptionTextView4);
        TextView recipeDescriptionTextView5 = findViewById(R.id.recipeDescriptionTextView5);
        TextView recipeDescriptionTextView6 = findViewById(R.id.recipeDescriptionTextView6);
        TextView recipeDescriptionTextView7 = findViewById(R.id.recipeDescriptionTextView7);
        TextView recipeDescriptionTextView8 = findViewById(R.id.recipeDescriptionTextView8);
        TextView recipeDescriptionTextView9 = findViewById(R.id.recipeDescriptionTextView9);
        TextView recipeDescriptionTextView10 = findViewById(R.id.recipeDescriptionTextView10);
        TextView recipeDescriptionTextView11 = findViewById(R.id.recipeDescriptionTextView11);

        recipeDescriptionTextView.setText("");
        recipeDescriptionTextView1.setText("");
        recipeDescriptionTextView2.setText("");
        recipeDescriptionTextView3.setText("");
        recipeDescriptionTextView4.setText("");
        recipeDescriptionTextView5.setText("");
        recipeDescriptionTextView6.setText("");
        recipeDescriptionTextView7.setText("");
        recipeDescriptionTextView8.setText("");
        recipeDescriptionTextView9.setText("");
        recipeDescriptionTextView10.setText("");
        recipeDescriptionTextView11.setText("");


        // Set the recipe details based on the recipe type
        // You can customize this part based on your needs
        if (recipeType == 2) {
            recipeTitleTextView.setText("Recipe List");
            recipeDescriptionTextView.setText("Breakfast\n-Bread, Avocado, Eggs, Salt, Pepper, Chopped fresh herbs.");
            recipeDescriptionTextView1.setText("Lunch\n-Whole wheat tortilla wrap, Slices of turkey breast, Slices of ham, Assorted vegetables, Hummus or Mayo, Salt, Pepper.");
            recipeDescriptionTextView2.setText("Dinner\n-Salmon fillets, Assorted vegetables, Olive oil, Salt, Pepper, Lemon wedges, Fresh herbs.");

        } else if (recipeType == 3) {
            recipeTitleTextView.setText("Recipe List");
            recipeDescriptionTextView3.setText("Breakfast\n-Bread, Eggs, 1/4 cup of cheese, Salt, Pepper, Butter, Herbs.");
            recipeDescriptionTextView4.setText("Lunch\n-Corn tortilla, olive oil, shrimp, cucumber, tomato, avocado, onion, lemon, lime, cilantro, salt, serrano pepper.");
            recipeDescriptionTextView5.setText("Dinner\n-Flour, chili powder, salt, black pepper, paprika, garlic, chicken wings, BBQ sauce, honey.");
            // Customize for Vegetable stir-fry recipe
        } else if (recipeType == 4) {
            recipeTitleTextView.setText("Recipe List");
            recipeDescriptionTextView6.setText("Breakfast\n-Banana, eggs, vanilla extract, oats, cinnamon.");
            recipeDescriptionTextView7.setText("Lunch\n-Beef, garlic, onion, pepper, salt, bread crumbs, parsley, eggs, ketchup, mustard, honey, bacon, cheese.");
            recipeDescriptionTextView8.setText("Dinner\n-Chicken, salt, pepper, garlic, ham, cheese, flour, eggs, breadcrumbs, broccoli, olive oil.");

            // Customize for Beef and broccoli stir-fry recipe
        } else if (recipeType == 5) {
            recipeTitleTextView.setText("Recipe List");
            recipeDescriptionTextView9.setText("Breakfast\n-Sausage, eggs, flour, tortilla, cheese.");
            recipeDescriptionTextView10.setText("Lunch\n-Greek yogurt, lime juice, pepper, avocado, chicken, celery, red onion, salt, bread, cilantro.");
            recipeDescriptionTextView11.setText("Dinner\n-Eggs, salt, bacon, onion, vegetable oil, rice, black pepper, sugar, soy sauce.");
            // Customize for Rice and Chicken recipe
        }
        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backIntent = new Intent(RecipeActivity.this, MealPlanActivity.class);
                startActivity(backIntent);
            }
        });
    }
}
