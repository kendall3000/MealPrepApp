package com.example.prep365;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageButton;



public class MealPlanActivity extends AppCompatActivity {

    private ImageButton imageButton2;
    private ImageButton imageButton3;
    private ImageButton imageButton4;
    private ImageButton imageButton5;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_plan);


        imageButton2 = findViewById(R.id.imageButton2);
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MealPlanActivity.this, MoreMealPlanActivity.class);
                intent.putExtra("imageButtonClicked", 2);
                startActivity(intent);
            }
        });

        imageButton3 = findViewById(R.id.imageButton3);
        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MealPlanActivity.this, MoreMealPlanActivity.class);
                intent.putExtra("imageButtonClicked", 3);
                startActivity(intent);
            }
        });

        imageButton4 = findViewById(R.id.imageButton4);
        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MealPlanActivity.this, MoreMealPlanActivity.class);
                intent.putExtra("imageButtonClicked", 4);
                startActivity(intent);
            }
        });

        imageButton5 = findViewById(R.id.imageButton5);
        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MealPlanActivity.this, MoreMealPlanActivity.class);
                intent.putExtra("imageButtonClicked", 5);
                startActivity(intent);
            }
        });

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backIntent = new Intent(MealPlanActivity.this, UserActivity.class);
                startActivity(backIntent);
            }
        });

    }
}
